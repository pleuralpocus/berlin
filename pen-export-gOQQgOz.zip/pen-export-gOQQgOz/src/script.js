document.getElementById('berlinForm').addEventListener('submit', function(event) {
    event.preventDefault();

    // Calcular el IMC
    const height = document.getElementById('height').value / 100;
    const weight = document.getElementById('weight').value;
    const bmi = (weight / (height * height)).toFixed(2);
    document.getElementById('bmi').value = bmi;

    // Evaluar las respuestas
    let scoreCategory1 = parseInt(document.querySelector('input[name="snoring"]:checked').value);
    scoreCategory1 += parseInt(document.querySelector('input[name="snoringLoud"]:checked').value);
    scoreCategory1 += parseInt(document.querySelector('input[name="snoringFrequency"]:checked').value);
    scoreCategory1 += parseInt(document.querySelector('input[name="snoringBother"]:checked').value);
    scoreCategory1 += parseInt(document.querySelector('input[name="breathing"]:checked').value) * 2;  // Multiplicamos por 2 según las reglas

    let scoreCategory2 = parseInt(document.querySelector('input[name="tired"]:checked').value);
    scoreCategory2 += parseInt(document.querySelector('input[name="fatigue"]:checked').value);
    scoreCategory2 += parseInt(document.querySelector('input[name="driving"]:checked').value);

    let scoreCategory3 = (parseInt(document.querySelector('input[name="hypertension"]:checked').value) || (bmi > 30)) ? 1 : 0;  // Si el IMC es mayor a 30, o si la respuesta a la hipertensión es 'Sí', entonces la categoría 3 es positiva

    // High Risk si hay 2 o más categorías con puntuación positiva. Low Risk si hay solo 1 o ninguna categoría con puntuación positiva
    let risk = ((scoreCategory1 >= 2 ? 1 : 0) + (scoreCategory2 >= 2 ? 1 : 0) + scoreCategory3) >= 2 ? "ALTO RIESGO" : "BAJO RIESGO";

    // Mostrar resultados
    document.getElementById('result').innerHTML = 'RIESGO DE APNEA DEL SUEÑO: ' + risk + '. ES URGENTE PEDIR UNA CITA.';
});
document.getElementById('berlinForm').addEventListener('submit', function(event) {
    event.preventDefault();

    let category1 = Number(document.querySelector('input[name="snoring"]:checked').value) +
        Number(document.querySelector('input[name="snoringLoud"]:checked').value) +
        Number(document.querySelector('input[name="snoringFrequency"]:checked').value) +
        Number(document.querySelector('input[name="snoringBother"]:checked').value) +
        Number(document.querySelector('input[name="breathing"]:checked').value);

    let category2 = Number(document.querySelector('input[name="tired"]:checked').value) +
        Number(document.querySelector('input[name="fatigue"]:checked').value) +
        Number(document.querySelector('input[name="driving"]:checked').value);

    let bmi = Number(document.getElementById('bmi').value);
    let category3 = (document.querySelector('input[name="hypertension"]:checked').value === '1' || bmi > 30) ? 1 : 0;

    let totalCategoriesPositive = (category1 >= 2 ? 1 : 0) + (category2 >= 2 ? 1 : 0) + category3;

    let resultDiv = document.getElementById('result');
    if (totalCategoriesPositive >= 2) {
        resultDiv.style.backgroundColor = "red";
        resultDiv.style.color = "white";
        resultDiv.innerHTML = "¡ALTO RIESGO! ES URGENTE PEDIR UNA CITA.";
    } else {
        resultDiv.style.backgroundColor = "green";
        resultDiv.style.color = "white";
        resultDiv.innerHTML = "Bajo riesgo. Sigue manteniendo un estilo de vida saludable.";
    }
});
